﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Programacion.Migrations
{
    /// <inheritdoc />
    public partial class primeramigra : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateOnly>(
                name: "FechaContrato",
                table: "Empleados",
                type: "date",
                nullable: false,
                defaultValue: new DateOnly(1, 1, 1));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "FechaContrato",
                table: "Empleados");
        }
    }
}
