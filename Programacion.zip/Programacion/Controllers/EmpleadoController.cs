﻿using Microsoft.AspNetCore.Mvc;
using Programacion.Data;
using Programacion.Models;
using Microsoft.EntityFrameworkCore;

namespace Programacion.Controllers
{
    public class EmpleadoController : Controller
    {
        private readonly AppDBContext _appDbContext;

        private static bool _hasShownWelcomeMessage = false;
        public EmpleadoController(AppDBContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        [HttpGet]
        public async Task<IActionResult> Lista()
        {
            /*bool showFirstTimeMessage = false;

            // Verificar si el middleware ha marcado la primera visita
            if (HttpContext.Items.ContainsKey("ShowFirstTimeMessage"))
            {
                showFirstTimeMessage = (bool)HttpContext.Items["ShowFirstTimeMessage"];
            }

            ViewBag.ShowFirstTimeMessage = showFirstTimeMessage;*/

            bool showFirstTimeMessage = false;

            if (!_hasShownWelcomeMessage)
            {
                showFirstTimeMessage = true;
                _hasShownWelcomeMessage = true; 
            }
            ViewBag.ShowFirstTimeMessage = showFirstTimeMessage;

            int visitCount = HttpContext.Session.GetInt32("VisitCount") ?? 0;

            
            visitCount++;

            
            HttpContext.Session.SetInt32("VisitCount", visitCount);

            
            ViewData["VisitCount"] = visitCount;

            List<Empleado> lista = await _appDbContext.Empleados.ToListAsync();
            return View(lista);
        }

        [HttpGet]
        public async Task<IActionResult> Nuevo()
        {
            
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Nuevo(Empleado empleado)
        {
            await _appDbContext.Empleados.AddAsync(empleado);
            await _appDbContext.SaveChangesAsync();

            return RedirectToAction(nameof(Lista));
        }

        [HttpGet]
        public async Task<IActionResult> Editar(int id)
        {
            Empleado empleado = await _appDbContext.Empleados.FirstAsync(e => e.IdEmpleado == id);

            return View(empleado);
        }

        [HttpPost]
        public async Task<IActionResult> Editar(Empleado empleado)
        {
            _appDbContext.Empleados.Update(empleado);
            await _appDbContext.SaveChangesAsync();

            return RedirectToAction(nameof(Lista));
        }

        [HttpGet]
        public async Task<IActionResult> Eliminar(int id)
        {
            Empleado empleado = await _appDbContext.Empleados.FirstAsync(e => e.IdEmpleado == id);

            _appDbContext.Empleados.Remove(empleado);
            await _appDbContext.SaveChangesAsync();

            return RedirectToAction(nameof(Lista));
        }
    }
}
